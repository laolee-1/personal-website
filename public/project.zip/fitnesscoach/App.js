import 'react-native-gesture-handler';
import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import SignUp from './SignUp';
import Login from './Login';
import Coach from './Coach';
import Student from './Student';
import ViewStorageData from './ViewStorageData';
import CommunitySupport from './CommunitySupport';
import Ionicons from 'react-native-vector-icons/Ionicons';
import ProfilePage from './ProfilePage';
import { Image } from 'react-native';
const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

function NavigationTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;
          if (route.name === 'Create Task') {
            iconName = 'create';
          } else if (route.name === 'Community Support') {
            iconName = 'people';
          } else if (route.name === 'Profile Page') {
            iconName = 'person';
          }
          return <Ionicons name={iconName} size={size} color={color} />;
        },
      })}>
      <Tab.Screen
        name="Create Task"
        component={Coach}
        options={{ headerShown: false }}
      />
      <Tab.Screen
        name="Community Support"
        component={CommunitySupport}
        options={{ headerShown: false }}
      />
      <Tab.Screen
        name="Profile Page"
        component={ProfilePage}
        options={{ headerShown: false }}
      />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Sign Up">
        <Stack.Screen name="Sign Up" component={SignUp} />
        <Stack.Screen name="Log In" component={Login} />
        <Stack.Screen
          name="Coach"
          component={NavigationTabs}
          options={{
            headerShown: true,
            headerRight: () => (
              <Image
                source={require('./assets/Logo.png')}
                style={{
                  resizeMode: 'contain',
                  width: 60,
                  height: 60,
                  marginRight: 10,
                }}
              />
            ),
          }}
        />
        <Stack.Screen
          name="Student"
          component={Student}
          options={{
            headerShown: true,
            headerRight: () => (
              <Image
                source={require('./assets/Logo.png')}
                style={{
                  resizeMode: 'contain',
                  width: 60,
                  height: 60,
                  marginRight: 10,
                }}
              />
            ),
          }}
        />
        <Stack.Screen name="Storage Data" component={ViewStorageData} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

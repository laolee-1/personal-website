import React from 'react';
import { render } from '@testing-library/react-native';
import Student from '../Student';

describe('<Student />', () => {
  it('renders step count correctly', () => {
    const { getByText } = render(<Student />);
    expect(getByText('Step Count: 0')).toBeTruthy();
  });

  it('renders total points correctly', () => {
    const { getByText } = render(<Student />);
    expect(getByText('Total Points: 0')).toBeTruthy();
  });
});
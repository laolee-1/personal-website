import React from 'react';
import { render, fireEvent, act } from '@testing-library/react-native';
import SignUp from '../SignUp';

global.alert = jest.fn(); // Mocking alert globally

describe('<SignUp />', () => {
  it('renders correctly', () => {
    const { getByPlaceholderText } = render(<SignUp />);
    expect(getByPlaceholderText('Choose a username')).toBeTruthy();
  });

  it('displays error when fields are not filled', async () => {
    const { getByText } = render(<SignUp />);
    const signUpButton = getByText('Sign Up');

    await act(async () => {
      fireEvent.press(signUpButton);
    });

    expect(await getByText('Error: All fields must be filled out.')).toBeTruthy();
  });

  it('displays success message on successful sign up', async () => {
    const { getByText, getByPlaceholderText } = render(<SignUp />);

    await act(async () => {
      fireEvent.changeText(getByPlaceholderText('Choose a username'), 'newuser');
      fireEvent.changeText(getByPlaceholderText('Choose a password'), 'newpassword');
      fireEvent.press(getByText('Sign Up'));
    });

    expect(await getByText('Success: Account has been created!')).toBeTruthy();
  });
});
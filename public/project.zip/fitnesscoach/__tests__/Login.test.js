import React from 'react';
import { render, fireEvent, act } from '@testing-library/react-native';
import Login from '../Login';

global.alert = jest.fn(); // Mocking alert globally

describe('<Login />', () => {
  it('renders correctly', () => {
    const { getByPlaceholderText } = render(<Login />);
    expect(getByPlaceholderText('Enter username')).toBeTruthy();
  });

  it('displays error message if username or password is incorrect', async () => {
    const { getByText, getByPlaceholderText } = render(<Login />);
    
    const usernameInput = getByPlaceholderText('Enter username');
    const passwordInput = getByPlaceholderText('Enter password');
    const loginButton = getByText('Log In');

    await act(async () => {
      fireEvent.changeText(usernameInput, 'wronguser');
      fireEvent.changeText(passwordInput, 'wrongpassword');
      fireEvent.press(loginButton);
    });

    expect(await getByText('Error please enter correct username or password.')).toBeTruthy();
  });

  it('navigates to Coach screen on successful login as coach', async () => {
    const mockNavigation = { navigate: jest.fn() };
    const { getByText, getByPlaceholderText } = render(<Login navigation={mockNavigation} />);

    const usernameInput = getByPlaceholderText('Enter username');
    const passwordInput = getByPlaceholderText('Enter password');
    const loginButton = getByText('Log In');

    await act(async () => {
      fireEvent.changeText(usernameInput, 'validcoach');
      fireEvent.changeText(passwordInput, 'correctpassword');
      fireEvent.press(loginButton);
    });

    expect(mockNavigation.navigate).toHaveBeenCalledWith('Coach');
  });
});
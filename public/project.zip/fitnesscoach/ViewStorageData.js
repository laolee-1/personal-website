import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  Button,
  ScrollView,
  Alert,
  SafeAreaView,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function ViewStorageData() {
  const [storageData, setStorageData] = useState([]);

  const getAllData = async () => {
    try {
      const keys = await AsyncStorage.getAllKeys();
      const result = await AsyncStorage.multiGet(keys);
      setStorageData(result);
    } catch (error) {
      Alert.alert('Error', 'Failed to load storage data.');
    }
  };

  const clearAllData = async () => {
    try {
      await AsyncStorage.clear();
      setStorageData([]);
      Alert.alert('Success', 'All data cleared.');
    } catch (error) {
      Alert.alert('Error', 'Failed to clear data.');
    }
  };

  useEffect(() => {
    getAllData();
  }, []);

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ScrollView style={{ padding: 20 }}>
        <Text style={{ fontSize: 24, marginBottom: 20 }}>Stored Data</Text>
        {storageData.length > 0 ? (
          storageData.map((item, index) => (
            <View key={index} style={{ marginBottom: 10 }}>
              <Text style={{ fontWeight: 'bold' }}>Key: {item[0]}</Text>
              <Text>Value: {item[1]}</Text>
            </View>
          ))
        ) : (
          <Text>No stored data found.</Text>
        )}

        <Button title="Refresh" onPress={getAllData} />
        <Button title="Clear All Data" onPress={clearAllData} color="red" />
      </ScrollView>
    </SafeAreaView>
  );
}

import React, { useState, useEffect, useRef } from 'react';
import {
  SafeAreaView,
  ScrollView,
  Button,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Image,
  TextInput,
  Alert,
} from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { CameraType } from 'expo-camera/build/legacy/Camera.types';
import * as ImagePicker from 'expo-image-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function App() {
  const [facing, setFacing] = useState(CameraType.back); //for flipping the camera
  const [cameraPermission, requestCameraPermission] = useCameraPermissions();
  const [galleryPermission, setGalleryPermission] = useState(null);
  const [cameraRef, setCameraRef] = useState(null);
  const [capturedImage, setCapturedImage] = useState(null);
  const [pickedImage, setPickedImage] = useState(null);
  const [caption, setCaption] = useState('');
  const [posts, setPosts] = useState([]);

  //request both camera and gallery permissions
  useEffect(() => {
    (async () => {
      await requestPermissions();
    })();
  }, []);

  const requestPermissions = async () => {
    const { status: cameraStatus } = await requestCameraPermission();
    const { status: galleryStatus } =
      await ImagePicker.requestMediaLibraryPermissionsAsync();
    setGalleryPermission(galleryStatus);

    if (cameraStatus !== 'granted' || galleryStatus !== 'granted') {
      Alert.alert(
        'Permissions Required',
        'We need camera and gallery permissions to allow you to take or pick images.',
        [{ text: 'OK' }]
      );
    }
  };

  //filp camera
  function toggleCameraFacing() {
    setFacing((current) => (current === 'back' ? 'front' : 'back'));
  }

  //capture an image using the camera
  const takePicture = async () => {
    if (cameraRef) {
      const photo = await cameraRef.takePictureAsync();
      setCapturedImage(photo.uri);
      setPickedImage(null);
    }
  };

  //pick an image from the gallery
  const pickImageFromGallery = async () => {
    const permissionResult =
      await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (permissionResult.granted === false) {
      Alert.alert(
        'Permission Required',
        'Please allow access to your gallery to pick images.'
      );
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 1,
    });

    if (!result.canceled && result.assets?.length > 0) {
      setPickedImage(result.assets[0].uri);
      setCapturedImage(null);
    } else {
      console.log('Image picking was canceled or failed');
    }
  };

  //save the post (image and caption) in AsyncStorage
  const savePost = async () => {
    const imageUri = capturedImage || pickedImage;
    if (!imageUri || !caption) {
      alert('Both an image and a caption are required.');
      return;
    }

    const newPost = { imageUri, caption };
    const updatedPosts = [...posts, newPost];

    try {
      await AsyncStorage.setItem('@posts', JSON.stringify(updatedPosts));
      setPosts(updatedPosts);
      setCapturedImage(null);
      setPickedImage(null);
      setCaption('');
      alert('Post saved successfully!');
    } catch (error) {
      console.error('Error saving post', error);
    }
  };

  //loading stored posts from AsyncStorage
  const loadPosts = async () => {
    try {
      const storedPosts = await AsyncStorage.getItem('@posts');
      if (storedPosts) {
        setPosts(JSON.parse(storedPosts));
      }
    } catch (error) {
      console.error('Error loading posts', error);
    }
  };

  if (!cameraPermission?.granted || galleryPermission !== 'granted') {
    return (
      <View style={styles.container}>
        <Text style={styles.message}>
          We need your permission to show the camera and access the gallery.
        </Text>
        <Button onPress={requestPermissions} title="Grant Permissions" />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.safeContainer}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Text style={styles.title}>Take or Pick a Picture and Post</Text>

        <View style={styles.camcontainer}>
          <CameraView
            style={styles.camera}
            facing={facing}
            ref={(ref) => setCameraRef(ref)}>
            <View style={styles.buttonContainer}>
              <TouchableOpacity
                style={styles.button}
                onPress={toggleCameraFacing}>
                <Text style={styles.text}>Flip Camera</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.button} onPress={takePicture}>
                <Text style={styles.text}>Take Picture</Text>
              </TouchableOpacity>
            </View>
          </CameraView>
        </View>

        <TouchableOpacity style={styles.button} onPress={pickImageFromGallery}>
          <Text style={styles.text}>Pick an Image from Gallery</Text>
        </TouchableOpacity>

        {capturedImage && (
          <Image source={{ uri: capturedImage }} style={styles.previewImage} />
        )}

        {pickedImage && (
          <Image source={{ uri: pickedImage }} style={styles.previewImage} />
        )}

        <TextInput
          style={styles.textinput}
          placeholder="Write a caption..."
          value={caption}
          onChangeText={setCaption}
        />

        <Button title="Post" onPress={savePost} />

        <Text style={styles.title}>Your Posts</Text>

        {posts.map((post, index) => (
          <View key={index} style={styles.post}>
            <Image source={{ uri: post.imageUri }} style={styles.postImage} />
            <Text style={styles.postCaption}>{post.caption}</Text>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeContainer: {
    flex: 1,
    backgroundColor: '#CCCCFF',
  },
  scrollContainer: {
    padding: 20,
  },
  container: {
    flex: 1,
    padding: 20,
    flexDirection: 'column',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 10,
  },
  camcontainer: {
    flex: 5,
  },
  camera: {
    flex: 1,
    width: '100%',
    height: 300,
    marginBottom: 20,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
    backgroundColor: 'transparent',
  },
  button: {
    alignItems: 'center',
    backgroundColor: 'blue',
    padding: 10,
    margin: 5,
  },
  text: {
    fontSize: 18,
    color: 'white',
  },
  previewImage: {
    width: '100%',
    height: 200,
    marginVertical: 10,
  },
  textinput: {
    borderWidth: 1,
    borderColor: '#ff5733',
    borderRadius: 10,
    backgroundColor: '#f1c40f',
    padding: 10,
    marginVertical: 10,
  },
  post: {
    marginBottom: 20,
  },
  postImage: {
    width: '100%',
    height: 200,
    marginBottom: 10,
  },
  postCaption: {
    fontSize: 16,
    fontStyle: 'italic',
  },
});

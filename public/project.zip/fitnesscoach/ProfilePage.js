import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Button,
  Image,
  TouchableOpacity,
  Alert,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function ProfilePage() {
  const [image, setImage] = useState(null);
  const [coachName, setCoachName] = useState('');
  const [userDescription, setUserDescription] = useState('');

  // Function to request permissions for gallery
  const requestPermissions = async () => {
    const { status: galleryStatus } =
      await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (galleryStatus !== 'granted') {
      Alert.alert(
        'Permissions Required',
        'We need gallery permissions to allow you to pick images.',
        [{ text: 'OK' }]
      );
      return false;
    }

    return true;
  };

  useEffect(() => {
    requestPermissions();
    fetchCoachName();
    fetchDescription();
  }, []);

  // Fetch the coach name from AsyncStorage
  const fetchCoachName = async () => {
    try {
      const name = await AsyncStorage.getItem('@coach_name');
      if (name !== null) {
        setCoachName(name);
      }
    } catch (error) {
      console.error('Error fetching coach name:', error);
    }
  };

  // Save description in AsyncStorage
  const saveDescription = async () => {
    try {
      await AsyncStorage.setItem('@user_description', userDescription);
      alert('Description saved successfully!');
    } catch (error) {
      console.error('Error saving description:', error);
    }
  };

  // Fetch description from AsyncStorage on load
  const fetchDescription = async () => {
    try {
      const description = await AsyncStorage.getItem('@user_description');
      if (description !== null) {
        setUserDescription(description);
      }
    } catch (error) {
      console.error('Error fetching description:', error);
    }
  };

  // Function to pick an image from the gallery
  const pickImageFromGallery = async () => {
    const permissionsGranted = await requestPermissions();

    if (!permissionsGranted) {
      console.error('Permissions not granted');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    // Access the uri from the assets array
    if (!result.canceled && result.assets && result.assets.length > 0) {
      const imageUri = result.assets[0].uri;
      setImage(imageUri);
      // Save image URI in AsyncStorage only if it's valid
      await AsyncStorage.setItem('@profile_image', imageUri);
    } else {
      console.error('Error: Image URI is undefined');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.middlecontainer}>
        <Text style={styles.headtext}>Welcome, Coach {coachName}!</Text>

        <TouchableOpacity style={styles.button} onPress={pickImageFromGallery}>
          <Text style={styles.buttonText}>Pick from Gallery</Text>
        </TouchableOpacity>

        {image && <Image source={{ uri: image }} style={styles.image} />}

        <TextInput
          style={styles.textinput}
          placeholder="Enter your description"
          value={userDescription}
          onChangeText={setUserDescription}
          multiline
        />
        <Button
          title="Save Description"
          onPress={saveDescription}
          color="darkblue"
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    flexDirection: 'column',
    backgroundColor: '#CCCCFF',
  },
  middlecontainer: {
    flex: 1,
    padding: 10,
  },
  headtext: {
    fontSize: 30,
    marginBottom: 10,
  },
  textinput: {
    borderWidth: 1,
    borderColor: '#ff5733',
    borderRadius: 10,
    backgroundColor: '#f1c40f',
    padding: 10,
    marginVertical: 10,
  },
  button: {
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 5,
    marginVertical: 10,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    textAlign: 'center',
  },
  image: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginVertical: 20,
    alignSelf: 'center',
  },
});

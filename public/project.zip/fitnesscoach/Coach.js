import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function Coach() {
  const [taskName, setTaskName] = useState('');
  const [taskDescription, setTaskDescription] = useState('');
  const [taskPoints, setTaskPoints] = useState('');

  const handleCreateTask = async () => {
    if (taskName && taskDescription && taskPoints) {
      const creationTime = new Date();
      const expirationTime = new Date(creationTime.getTime() + 60 * 1000);

      const newTask = {
        name: taskName,
        description: taskDescription,
        points: taskPoints,
        createdAt: creationTime.toISOString(),
        expiresAt: expirationTime.toISOString(),
      };

      try {
        const storedTasks = await AsyncStorage.getItem('@tasks');
        const tasksArray = storedTasks ? JSON.parse(storedTasks) : [];
        tasksArray.push(newTask);

        await AsyncStorage.setItem('@tasks', JSON.stringify(tasksArray));

        console.log('Tasks saved in AsyncStorage:', tasksArray);

        alert('Successfully created task with a 1-minute timer!');

        setTaskName('');
        setTaskDescription('');
        setTaskPoints('');
      } catch (error) {
        console.error('Error saving task:', error);
        alert('Failed to create task.');
      }
    } else {
      alert('Please fill all the fields.');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.middlecontainer}>
        <Text style={styles.headtext}>Create a Workout Task</Text>

        <Text style={styles.text}>Task Name:</Text>
        <TextInput
          style={styles.textinput}
          placeholder="Enter workout name"
          value={taskName}
          onChangeText={setTaskName}
          placeholderTextColor={'white'}
        />

        <Text style={styles.text}>Description:</Text>
        <TextInput
          style={styles.textinput}
          placeholder="Enter workout description"
          value={taskDescription}
          onChangeText={setTaskDescription}
          placeholderTextColor={'white'}
        />

        <Text style={styles.text}>Points:</Text>
        <TextInput
          style={styles.textinput}
          placeholder="Enter points"
          keyboardType="numeric"
          value={taskPoints}
          onChangeText={setTaskPoints}
          placeholderTextColor={'white'}
        />

        <Button
          title="Create Task"
          color="darkblue"
          onPress={handleCreateTask}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    flexDirection: 'column',
    backgroundColor: '#CCCCFF',
  },
  middlecontainer: {
    flex: 1,
    padding: 10,
  },
  headtext: {
    fontSize: 30,
    marginBottom: 10,
  },
  text: {
    fontSize: 15,
    fontStyle: 'italic',
    fontWeight: 'bold',
  },
  textinput: {
    borderWidth: 1,
    borderColor: '#ff5733',
    borderRadius: 10,
    backgroundColor: '#f1c40f',
    padding: 10,
    marginVertical: 10,
  },
});

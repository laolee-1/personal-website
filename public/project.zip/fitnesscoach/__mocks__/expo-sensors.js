export const Accelerometer = {
    addListener: jest.fn(),
    removeAllListeners: jest.fn(),
  };
  
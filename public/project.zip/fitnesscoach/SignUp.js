import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  Alert,
  Image,
  StyleSheet,
  Animated,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Picker } from '@react-native-picker/picker';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function SignUp({ navigation }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('coach');

  //creating a fadeAnimation value using useRef
  const fadeAni = useRef(new Animated.Value(0)).current;

  //helper function for fetching users from AsyncStorage
  const getStoredUsers = async () => {
    try {
      const storedUsers = await AsyncStorage.getItem('@users');
      return storedUsers ? JSON.parse(storedUsers) : [];
    } catch (error) {
      console.error('Error retrieving users:', error);
      return [];
    }
  };

  //handling sign-up
  const handleSignUp = async () => {
    if (username && password) {
      try {
        const users = await getStoredUsers();
        const userExists = users.some((user) => user.username === username);

        if (userExists) {
          alert('Error: Username is already taken.');
          return;
        }

        const newUser = { username, password, role };
        const updatedUsers = [...users, newUser];

        await AsyncStorage.setItem('@users', JSON.stringify(updatedUsers));
        alert('Success: Account has been created!');
      } catch (error) {
        alert('Error: An issue occurred while creating the account.');
      }
    } else {
      alert('Error: All fields must be filled out.');
    }
  };

  //animation effect for fading in
  useEffect(() => {
    Animated.timing(fadeAni, {
      toValue: 1,
      duration: 3000,
      useNativeDriver: true,
    }).start();
  }, [fadeAni]);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.topcontainer}>
        <Text style={styles.text}>Register</Text>
        <Animated.View style={{ ...styles.imageContainer, opacity: fadeAni }}>
          <Image source={require('./assets/Logo.png')} style={styles.image} />
        </Animated.View>
      </View>

      <View style={styles.middlecontainer}>
        <Text style={styles.usertext}>Username:</Text>
        <TextInput
          style={styles.textinput}
          placeholder="Choose a username"
          value={username}
          onChangeText={setUsername}
          placeholderTextColor={'white'}
        />

        <Text style={styles.usertext}>Password:</Text>
        <TextInput
          style={styles.textinput}
          placeholder="Choose a password"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
          placeholderTextColor={'white'}
        />
        <View style={styles.pickercontainer}>
          <Text style={styles.usertext}>Role:</Text>
          <Picker
            selectedValue={role}
            onValueChange={(value) => setRole(value)}
            style={styles.picker}>
            <Picker.Item label="Coach" value="coach" />
            <Picker.Item label="Student" value="student" />
          </Picker>
        </View>

        <View style={styles.buttoncontainer}>
          <Button title="Sign Up" onPress={handleSignUp} color="blue" />

          <Button
            title="Already have an account? Log In"
            onPress={() => navigation.navigate('Log In')}
            color="darkblue"
          />
          <Button
            title="View Stored Data"
            onPress={() => navigation.navigate('Storage Data')}
            color="darkblue"
          />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    flexDirection: 'column',
    backgroundColor: '#CCCCFF',
  },
  topcontainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  middlecontainer: {
    flex: 2,
    padding: 10,
  },
  pickercontainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  buttoncontainer: {
    flexDirection: 'column',
    flexGrow: 1,
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  imageContainer: {
    width: '100%',
    height: '100%',
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
    borderWidth: 5,
    borderRadius: 40,
    borderColor: 'gold',
  },
  text: {
    fontSize: 20,
    fontStyle: 'italic',
    marginBottom: 10,
  },
  textinput: {
    borderWidth: 1,
    borderColor: '#ff5733',
    borderRadius: 10,
    backgroundColor: '#f1c40f',
    padding: 10,
    marginVertical: 10,
  },
  usertext: {
    fontSize: 20,
  },
  picker: {
    height: '10%',
    width: '80%',
    marginVertical: 10,
    backgroundColor: 'white',
  },
});

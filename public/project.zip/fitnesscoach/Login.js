import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  Alert,
  StyleSheet,
  Animated,
  Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function Login({ navigation }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  //creating a x-axis translation animation value using useRef
  const transXAni = useRef(new Animated.Value(300)).current;

  //helper function for fetching users from AsyncStorage
  const getStoredUsers = async () => {
    try {
      const storedUsers = await AsyncStorage.getItem('@users');
      return storedUsers ? JSON.parse(storedUsers) : [];
    } catch (error) {
      console.error('Error fetching users from storage:', error);
      return [];
    }
  };

  //handling the login
  const handleLogin = async () => {
    try {
      const users = await getStoredUsers();
      const user = users.find(
        (u) => u.username === username && u.password === password
      );

      if (user) {
        alert('Success you are now logged in!');
        //navigate based on user role
        user.role === 'coach'
          ? navigation.navigate('Coach')
          : navigation.navigate('Student', { username: user.username });
      } else {
        alert('Error please enter correct username or password.');
      }
    } catch (error) {
      alert('Error an issue occurred when logging in.');
    }
  };

  //animation effect
  useEffect(() => {
    Animated.timing(transXAni, {
      toValue: 0,
      duration: 1000,
      useNativeDriver: true,
    }).start();
  }, [transXAni]);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.topcontainer}>
        <Animated.View
          style={{
            ...styles.imageContainer,
            transform: [{ translateX: transXAni }],
          }}>
          <Image source={require('./assets/Logo.png')} style={styles.image} />
        </Animated.View>
      </View>

      <View style={styles.middlecontainer}>
        <Text style={styles.usertext}>Username:</Text>
        <TextInput
          style={styles.textinput}
          placeholder="Enter username"
          value={username}
          onChangeText={setUsername}
          placeholderTextColor={'white'}
        />

        <Text style={styles.usertext}>Password:</Text>
        <TextInput
          style={styles.textinput}
          placeholder="Enter password"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
          placeholderTextColor={'white'}
        />

        <Button title="Log In" onPress={handleLogin} color={'darkblue'} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    flexDirection: 'column',
    backgroundColor: '#CCCCFF',
  },
  topcontainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  middlecontainer: {
    flex: 1,
    padding: 10,
  },
  imageContainer: {
    width: '100%',
    height: '100%',
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
    borderWidth: 5,
    borderRadius: 40,
    borderColor: 'gold',
  },
  textinput: {
    borderWidth: 1,
    borderColor: '#ff5733',
    borderRadius: 10,
    backgroundColor: '#f1c40f',
    padding: 10,
    marginVertical: 10,
  },
  usertext: {
    fontSize: 20,
  },
});

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  Alert,
  Button,
  Platform,
  StyleSheet,
  TextInput,
  SafeAreaView,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { StatusBar } from 'expo-status-bar';
import { Accelerometer } from 'expo-sensors';
import Ionicons from 'react-native-vector-icons/Ionicons';

const projectId = '6bf462b3-c862-4e4a-ab84-73e05fdf1ed6'; //replace with your actual project ID

//notification handler
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

//ensure android notification channel is set
if (Platform.OS === 'android') {
  Notifications.setNotificationChannelAsync('default', {
    name: 'default',
    importance: Notifications.AndroidImportance.MAX,
    vibrationPattern: [0, 250, 250, 250],
    lightColor: '#FF231F7C',
    sound: true,
  });
}

export default function Student({ route, navigation }) {
  const [tasks, setTasks] = useState([]);
  const [totalPoints, setTotalPoints] = useState(0);
  const [stepCount, setStepCount] = useState(0);
  const username = route?.params?.username;
  const [subscription, setSubscription] = useState(null);

  //calorieNinjas API integrate
  const [query, setQuery] = useState('');
  const [nutritionData, setNutritionData] = useState([]);

  //fetching calorie data using CalorieNinjas API
  const fetchNutritionData = async () => {
    const apiKey = 'gW97teh809Ml9+ZmTY5R2A==zWhyaEDGXxNr17cp'; //replace new api key from CalorieNinjas if api key expired.
    const apiUrl = `https://api.calorieninjas.com/v1/nutrition?query=${query}`;

    try {
      const response = await fetch(apiUrl, {
        method: 'GET',
        headers: {
          'X-Api-Key': apiKey,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const result = await response.json();
        console.log('Nutrition data:', result.items);
        setNutritionData(result.items);
      } else {
        console.error('Error fetching data:', response.statusText);
      }
    } catch (error) {
      console.error('Fetch error:', error);
    }
  };

  //subscribe to accelerometer data
  useEffect(() => {
    const _subscribe = () => {
      setSubscription(
        Accelerometer.addListener((accelerometerData) => {
          handleAccelerometerData(accelerometerData);
        })
      );
      Accelerometer.setUpdateInterval(1000);
    };

    const _unsubscribe = () => {
      subscription && subscription.remove();
      setSubscription(null);
    };

    _subscribe();
    return () => _unsubscribe(); //clean up subscription when the component unmounts
  }, []);

  //function handling detection steps based on accelerometer data
  const handleAccelerometerData = (data) => {
    const { x, y, z } = data;
    const magnitude = Math.sqrt(x * x + y * y + z * z);

    if (magnitude > 1.2) {
      setStepCount((prevStepCount) => prevStepCount + 1);
    }
  };

  useEffect(() => {
    (async () => {
      if (Device.isDevice && Platform.OS !== 'web') {
        try {
          const { status: existingStatus } =
            await Notifications.getPermissionsAsync();
          let finalStatus = existingStatus;
          if (existingStatus !== 'granted') {
            const { status } = await Notifications.requestPermissionsAsync();
            finalStatus = status;
          }
          if (finalStatus !== 'granted') {
            alert('Failed to get push token for push notification!');
            return;
          }
          const token = (
            await Notifications.getExpoPushTokenAsync({ projectId })
          ).data;
          console.log(`Expo push token: ${token}`);
        } catch (error) {
          console.error('Error getting Expo push token:', error);
        }
      } else {
        alert('You must use a real device to test push notifications.');
      }
    })();
  }, []);

  //send notification when there are tasks
  const sendTaskNotification = async (taskCount) => {
    if (Device.isDevice) {
      try {
        const token = (await Notifications.getExpoPushTokenAsync({ projectId }))
          .data;

        const notificationPayload = {
          to: token,
          sound: 'default',
          title: 'You have tasks to complete!',
          body: `You have ${taskCount} tasks assigned to you. Please check your tasks.`,
        };

        console.log('Sending notification: ', notificationPayload); // Debugging

        const response = await fetch('https://exp.host/--/api/v2/push/send', {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(notificationPayload),
        });

        const responseData = await response.json();
        console.log('Push notification response:', responseData);
      } catch (error) {
        console.error('Error sending notification:', error);
      }
    }
  };

  //function to complete task
  const completeTask = async (taskIndex) => {
    try {
      const completedTask = tasks[taskIndex];
      const updatedPoints = totalPoints + parseInt(completedTask.points, 10);
      setTotalPoints(updatedPoints);

      await AsyncStorage.setItem(
        `@totalPoints_${username}`,
        updatedPoints.toString()
      );

      const updatedTasks = tasks.filter((_, index) => index !== taskIndex);
      setTasks(updatedTasks);
      await AsyncStorage.setItem('@tasks', JSON.stringify(updatedTasks));

      Alert.alert(
        'Task Completed',
        `You earned ${completedTask.points} points!`
      );
    } catch (error) {
      alert('Error failed to complete task.');
    }
  };

  useEffect(() => {
    //get task
    const fetchTasks = async () => {
      try {
        const storedTasks = await AsyncStorage.getItem('@tasks');
        if (storedTasks) {
          const taskList = JSON.parse(storedTasks);
          setTasks(taskList);

          if (taskList.length > 0) {
            sendTaskNotification(taskList.length);
          }
        } else {
          alert('No Tasks.');
        }
      } catch (error) {
        alert('Error failed to load tasks.');
      }
    };

    const initializeData = async () => {
      if (!username) {
        alert('Error no username provided.');
        navigation.navigate('Log In');
        return;
      }

      //get tasks and total points
      await fetchTasks();
      const storedPoints = await AsyncStorage.getItem(
        `@totalPoints_${username}`
      );
      setTotalPoints(storedPoints ? parseInt(storedPoints, 10) : 0);
    };

    initializeData();
  }, [username, navigation]);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.middlecontainer}>
        <Text style={styles.headtext}>Student Tasks</Text>
        <Text style={styles.text}>Total Points: {totalPoints}</Text>

        {tasks.length > 0 ? (
          <FlatList
            data={tasks}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item, index }) => (
              <View style={styles.taskItem}>
                <Text style={styles.text}>{item.name}</Text>
                <Text>{item.description}</Text>
                <Text>Points: {item.points}</Text>
                <Button
                  title="Complete"
                  onPress={() => completeTask(index)}
                  color="darkblue"
                />
              </View>
            )}
          />
        ) : (
          <Text>No tasks available.</Text>
        )}
      </View>

      <View style={styles.stepcountcontainer}>
        <Ionicons name="walk" size={30} color={'black'} />
        <Text style={styles.text}>Step Count: {stepCount}</Text>
      </View>

      <View style={styles.apicontainer}>
        <TextInput
          style={styles.textinput}
          placeholder="Enter food item (e.g., '3lb carrots')"
          value={query}
          onChangeText={setQuery}
        />
        <Button
          title="Get Nutrition Info"
          onPress={fetchNutritionData}
          color={'darkblue'}
        />

        <Ionicons name="nutrition" size={30} />

        {nutritionData.length > 0 && (
          <FlatList
            data={nutritionData}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item }) => (
              <View style={styles.nutritionItem}>
                <Text style={styles.text}>
                  {item.name} - Calories: {item.calories} kcal
                </Text>
                <Text>
                  Protein: {item.protein_g}g, Carbs:{' '}
                  {item.carbohydrates_total_g}g, Fat: {item.fat_total_g}g
                </Text>
              </View>
            )}
          />
        )}
      </View>
      <StatusBar style="auto" />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
    flexDirection: 'column',
    backgroundColor: '#CCCCFF',
  },
  middlecontainer: {
    flex: 1,
    padding: 10,
  },
  stepcountcontainer: {
    flex: 0.1,
    flexDirection: 'row',
  },
  apicontainer: {
    flex: 1,
  },
  headtext: {
    fontSize: 30,
    marginBottom: 10,
  },
  text: {
    fontSize: 15,
    fontStyle: 'italic',
    fontWeight: 'bold',
  },
  textinput: {
    borderWidth: 1,
    borderColor: '#ff5733',
    borderRadius: 10,
    backgroundColor: '#f1c40f',
    padding: 10,
    marginVertical: 10,
  },
  taskItem: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginVertical: 5,
    width: '100%',
    flex: 1,
  },
  nutritionItem: {
    borderWidth: 1,
    borderRadius: 10,
    borderColor: '#ff5733',
    backgroundColor: '#f1c40f',
    padding: 10,
    marginVertical: 5,
    width: '100%',
    flex: 1,
  },
});
